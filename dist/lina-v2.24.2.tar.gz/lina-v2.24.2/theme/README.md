# 主题颜色
```
alpha-1: "rgba(64, 158, 255, 0.1)"
alpha-2: "rgba(64, 158, 255, 0.2)"
alpha-3: "rgba(64, 158, 255, 0.3)"
alpha-4: "rgba(64, 158, 255, 0.4)"
alpha-5: "rgba(64, 158, 255, 0.5)"
alpha-6: "rgba(64, 158, 255, 0.6)"
alpha-7: "rgba(64, 158, 255, 0.7)"
alpha-8: "rgba(64, 158, 255, 0.8)"
alpha-9: "rgba(64, 158, 255, 0.9)"
light-1: "#53a8ff"
light-2: "#66b1ff"
light-3: "#79bbff"
light-4: "#8cc5ff"
light-5: "#a0cfff"
light-6: "#b3d8ff"
light-7: "#c6e2ff"
light-8: "#d9ecff"
light-9: "#ecf5ff"
primary: "#409EFF"
```
primary是初始主题颜色，其他颜色均属于primary的系列颜色